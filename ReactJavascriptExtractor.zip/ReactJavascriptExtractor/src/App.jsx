import React from 'react';
import SorteadorDeTimes from './SorteadorDeTimes';

function App() {
  return (
    <div className="App">
      <SorteadorDeTimes />
    </div>
  );
}

export default App;
